package com.ksh.hexagonalarchitecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexagonalArchitectureApplicationTests {

    @Test
    void contextLoads() {
    }

}
